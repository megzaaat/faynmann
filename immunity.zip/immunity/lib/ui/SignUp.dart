import 'package:flutter/material.dart';
import 'package:immunity/ui/login.dart';
import 'package:immunity/ui/login.dart';

class SignUp extends StatefulWidget {
  @override
  _SignUpState createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  TextEditingController fullNameController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController mailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController confirmPassController = TextEditingController();
  TextEditingController dateController = TextEditingController();
  TextEditingController genderController = TextEditingController();


  String dropdownValue = 'One';
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        Container(
          color: Colors.white,
        ),
        Image.asset(
          "images/BG.png",
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          fit: BoxFit.cover,
          color: Color(0xFFfafafa),
        ),
        Scaffold(
            backgroundColor: Colors.transparent,
            appBar: AppBar(backgroundColor: Colors.transparent,elevation: 0,iconTheme: IconThemeData(color: Color(0xFF4E7A9F)),),
            body: ListView(
              padding: EdgeInsets.only(top: 15, left: 30, right: 30),
              children: <Widget>[
                Container(
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(25)),
                      color: Colors.white,
                      boxShadow: [
                        new BoxShadow(
                          color: Colors.black12,
                          blurRadius: 20.0,
                        ),
                      ]),
                  child: TextField(
                    controller: fullNameController,
                    keyboardType: TextInputType.emailAddress,
                    style: TextStyle(color: Color(0xFF4E7A9F)),
                    cursorColor: Color(0xFF4E7A9F),
                    decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: 'Full Name',
                        hintStyle: TextStyle(
                            fontWeight: FontWeight.w300,
                            color: Color(0xFF4E7A9F)),
                        icon: Icon(
                          Icons.person,
                          size: 28,
                          color: Color(0xFF4E7A9F),
                        )),
                  ),
                ), //FullName
                Padding(
                  padding: EdgeInsets.all(11),
                ),
                Container(
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(25)),
                      color: Colors.white,
                      boxShadow: [
                        new BoxShadow(
                          color: Colors.black12,
                          blurRadius: 20.0,
                        ),
                      ]),
                  child: TextField(
                    controller: phoneController,
                    keyboardType: TextInputType.text,
                    style: TextStyle(color: Color(0xFF4E7A9F)),
                    cursorColor: Color(0xFF4E7A9F),
                    decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: 'Phone Number',
                        hintStyle: TextStyle(
                            fontWeight: FontWeight.w300,
                            color: Color(0xFF4E7A9F)),
                        icon: Icon(
                          Icons.phone,
                          size: 28,
                          color: Color(0xFF4E7A9F),
                        )),
                  ),
                ), //PhoneNumber
                Padding(
                  padding: EdgeInsets.all(11),
                ),
                Container(
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(25)),
                      color: Colors.white,
                      boxShadow: [
                        new BoxShadow(
                          color: Colors.black12,
                          blurRadius: 20.0,
                        ),
                      ]),
                  child: TextField(
                    controller: mailController,
                    keyboardType: TextInputType.text,
                    style: TextStyle(color: Color(0xFF4E7A9F)),
                    cursorColor: Color(0xFF4E7A9F),
                    decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: 'E-mail Adress',
                        hintStyle: TextStyle(
                            fontWeight: FontWeight.w300,
                            color: Color(0xFF4E7A9F)),
                        icon: Icon(
                          Icons.mail,
                          size: 28,
                          color: Color(0xFF4E7A9F),
                        )),
                  ),
                ), //Email
                Padding(
                  padding: EdgeInsets.all(11),
                ),
                Container(
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(25)),
                      color: Colors.white,
                      boxShadow: [
                        new BoxShadow(
                          color: Colors.black12,
                          blurRadius: 20.0,
                        ),
                      ]),
                  child: TextField(
                    controller: passwordController,
                    keyboardType: TextInputType.text,
                    obscureText: true,
                    style: TextStyle(color: Color(0xFF4E7A9F)),
                    cursorColor: Color(0xFF4E7A9F),
                    decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: 'Password',
                        hintStyle: TextStyle(
                            fontWeight: FontWeight.w300,
                            color: Color(0xFF4E7A9F)),
                        icon: Icon(
                          Icons.lock,
                          size: 28,
                          color: Color(0xFF4E7A9F),
                        )),
                  ),
                ), //Password
                Padding(
                  padding: EdgeInsets.all(11),
                ),
                Container(
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(25)),
                      color: Colors.white,
                      boxShadow: [
                        new BoxShadow(
                          color: Colors.black12,
                          blurRadius: 20.0,
                        ),
                      ]),
                  child: TextField(
                    controller: confirmPassController,
                    keyboardType: TextInputType.text,
                    obscureText: true,
                    style: TextStyle(color: Color(0xFF4E7A9F)),
                    cursorColor: Color(0xFF4E7A9F),
                    decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: 'Confirm Password',
                        hintStyle: TextStyle(
                            fontWeight: FontWeight.w300,
                            color: Color(0xFF4E7A9F)),
                        icon: Icon(
                          Icons.lock,
                          size: 28,
                          color: Color(0xFF4E7A9F),
                        )),
                  ),
                ), //ConfirmPassword
                Padding(
                  padding: EdgeInsets.all(11),
                ),
                Container(
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(25)),
                      color: Colors.white,
                      boxShadow: [
                        new BoxShadow(
                          color: Colors.black12,
                          blurRadius: 20.0,
                        ),
                      ]),
                  child: TextField(
                    controller: dateController,
                    keyboardType: TextInputType.text,
                    style: TextStyle(color: Color(0xFF4E7A9F)),
                    cursorColor: Color(0xFF4E7A9F),
                    decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: 'Date of Birth',
                        hintStyle: TextStyle(
                            fontWeight: FontWeight.w300,
                            color: Color(0xFF4E7A9F)),
                        icon: Icon(
                          Icons.calendar_today,
                          size: 28,
                          color: Color(0xFF4E7A9F),
                        )),
                  ),
                ), //date
                Padding(
                  padding: EdgeInsets.all(11),
                ),
                Container(
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(25)),
                      color: Colors.white,
                      boxShadow: [
                        new BoxShadow(
                          color: Colors.black12,
                          blurRadius: 20.0,
                        ),
                      ]),
                  child: DropdownButtonFormField<String>(
                    decoration: InputDecoration.collapsed(
                      hintText: 'Select your Gender',
                      hintStyle: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w300,
                        fontFamily: ('Cairo'),
                        color: Color(0xFF4E7A9F),
                      ),
                    ),
                    onChanged: (newValue) {
                      setState(() {
                        dropdownValue = newValue;
                      });
                    },
                    items: <String>['Male', 'Female']
                        .map<DropdownMenuItem<String>>((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(
                          value,
                          style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                              fontFamily: ('Cairo'),
                              color: Color(0xFF4E7A9F)),
                        ),
                      );
                    }).toList(),
                  ),
                ), //gender
                Padding(
                  padding: EdgeInsets.all(10),
                ),
                Container(
                  padding: const EdgeInsets.only(top: 1.0, right: 80, left: 80),
                  child: RaisedButton(
                    padding: const EdgeInsets.only(top: 0.0, right: 0, left: 0),
                    onPressed: () {},
                    textColor: Colors.white,
                    child: Container(
                      height: MediaQuery.of(context).size.height * 0.08,
                      width: MediaQuery.of(context).size.width * 0.5,
                      decoration: const BoxDecoration(
                          gradient: LinearGradient(
                              colors: [Color(0xFFe37b7b), Color(0xFFF6CBCA)],
                              begin: FractionalOffset(0.0, 0.0),
                              end: FractionalOffset(0.75, 0.0),
                              stops: [0.0, 1.0],
                              tileMode: TileMode.clamp),
                          borderRadius: BorderRadius.all(Radius.circular(25))),
                      child: Center(
                        child: Text(
                          'Sign Up',
                          style: TextStyle(
                              fontSize: 22, fontWeight: FontWeight.w600),
                        ),
                      ),
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: new BorderRadius.circular(28),
                    ),
                    elevation: 8,
                  ),
                ), //SignUp Button
                Padding(
                  padding: EdgeInsets.all(10),
                ),
              ],
            ))
      ],
    );
  }
}
