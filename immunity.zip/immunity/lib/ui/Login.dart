import 'package:flutter/material.dart';
import 'package:immunity/ui/ConfirmLogin.dart';
import 'package:immunity/ui/SignUp.dart';
import 'package:immunity/ui/Home.dart';

class Login extends StatefulWidget {
  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        Container(
          color: Colors.white,
        ),
        Image.asset(
          "images/BG.png",
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          fit: BoxFit.cover,
          color: Color(0xFFfafafa),
        ),
        Scaffold(
            backgroundColor: Colors.transparent,
            body: ListView(
              padding: EdgeInsets.only(top: 80, left: 30, right: 30),
              children: <Widget>[
                Image(image: AssetImage('images/heartRate.png'),),
                Padding(
                  padding: EdgeInsets.all(15),
                ),
                RaisedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => ConfirmLogin()),
                        );
                      },
                      textColor: Colors.white,
                      padding: const EdgeInsets.all(0.07),
                      child: Container(
                        height: MediaQuery.of(context).size.height*0.08,
                        width: MediaQuery.of(context).size.width,
                        decoration: const BoxDecoration(
                          gradient: LinearGradient(
                              colors: [Color(0xFFe37b7b), Color(0xFFF6CBCA)],
                              begin: FractionalOffset(0.0, 0.0),
                              end: FractionalOffset(0.75, 0.0),
                              stops: [0.0, 1.0],
                              tileMode: TileMode.clamp),
                          borderRadius: BorderRadius.all(Radius.circular(25))
                        ),
                        padding: const EdgeInsets.all(10.0),
                        child: Center(
                          child: Text(
                            'Login',
                            style: TextStyle(
                                fontSize: 22, fontWeight: FontWeight.w600),
                          ),
                        ),
                      ),
                   shape: RoundedRectangleBorder(
                       borderRadius: new BorderRadius.circular(28),
                   ),
                   elevation: 8,
                 ),//Login Button

                Padding(
                  padding: EdgeInsets.all(15),
                ),
                RaisedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => SignUp()),
                    );
                  },
                  textColor: Colors.white,
                  padding: const EdgeInsets.all(0.07),
                  child: Container(
                    height: MediaQuery.of(context).size.height*0.08,
                    width: MediaQuery.of(context).size.width,
                    decoration: const BoxDecoration(
                        gradient: LinearGradient(
                            colors: [Color(0xFFe37b7b), Color(0xFFF6CBCA)],
                            begin: FractionalOffset(0.0, 0.0),
                            end: FractionalOffset(0.75, 0.0),
                            stops: [0.0, 1.0],
                            tileMode: TileMode.clamp),
                        borderRadius: BorderRadius.all(Radius.circular(25))
                    ),
                    padding: const EdgeInsets.all(10.0),
                    child: Center(
                      child: Text(
                        'Sign Up',
                        style: TextStyle(
                            fontSize: 22, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: new BorderRadius.circular(28),
                  ),
                  elevation: 8,
                ),
                Padding(
                  padding: EdgeInsets.all(15),
                ),
                RaisedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => Home()),
                    );
                  },
                  textColor: Colors.white,
                  padding: const EdgeInsets.all(0.07),
                  child: Container(
                    height: MediaQuery.of(context).size.height*0.08,
                    width: MediaQuery.of(context).size.width,
                    decoration: const BoxDecoration(
                        gradient: LinearGradient(
                            colors: [Color(0xFFe37b7b), Color(0xFFF6CBCA)],
                            begin: FractionalOffset(0.0, 0.0),
                            end: FractionalOffset(0.75, 0.0),
                            stops: [0.0, 1.0],
                            tileMode: TileMode.clamp),
                        borderRadius: BorderRadius.all(Radius.circular(22))
                    ),
                    padding: const EdgeInsets.all(10.0),
                    child: Center(
                      child: Text(
                        'Not Now',
                        style: TextStyle(
                            fontSize: 22, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: new BorderRadius.circular(28),
                  ),
                  elevation: 8,
                ),
                Padding(
                  padding: EdgeInsets.all(12),
                ),


              ],
            ))
      ],
    );
  }
}
