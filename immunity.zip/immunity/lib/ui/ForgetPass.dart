import 'package:flutter/material.dart';

class ForgetPass extends StatefulWidget {
  @override
  _ForgetPassState createState() => _ForgetPassState();
}

class _ForgetPassState extends State<ForgetPass> {
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        Container(
          color: Colors.white,
        ),
        Image.asset(
          "images/BG.png",
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          fit: BoxFit.cover,
          color: Color(0xFFfafafa),
        ),
        Scaffold(
            backgroundColor: Colors.transparent,
            appBar: AppBar(backgroundColor: Colors.transparent,elevation: 0,iconTheme: IconThemeData(color: Color(0xFF4E7A9F)),),
            body: ListView(
              padding: EdgeInsets.only(top: 75, left: 30, right: 30),
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.all(80),
                ),
                Center(
                  child: Text(
                    'Please confirm your password so that we can send a temporary one ',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.w600,color: Color(0xFF4E7A9F)),textAlign: TextAlign.center,
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(50),
                ),
                Container(
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(25)),
                      color: Colors.white,
                      boxShadow: [
                        new BoxShadow(
                          color: Colors.black12,
                          blurRadius: 20.0,
                        ),
                      ]),
                  child: TextField(
                    keyboardType: TextInputType.phone,
                    style: TextStyle(color: Color(0xFF4E7A9F)),
                    cursorColor: Color(0xFF4E7A9F),
                    decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: 'Phone Number',
                        hintStyle: TextStyle(
                            fontWeight: FontWeight.w300,
                            color: Color(0xFF4E7A9F)),
                        icon: Icon(
                          Icons.phone,
                          size: 28,
                          color: Color(0xFF4E7A9F),
                        )),
                  ),
                ), //Email
                Padding(
                  padding: EdgeInsets.all(15),
                ),
                Container(
                  padding:
                      const EdgeInsets.only(top: 10.0, right: 80, left: 80),
                  child: RaisedButton(
                    padding: const EdgeInsets.only(top: 0.0, right: 0, left: 0),
                    onPressed: () {},
                    textColor: Colors.white,
                    child: Container(
                      height: MediaQuery.of(context).size.height * 0.08,
                      width: MediaQuery.of(context).size.width * 0.5,
                      decoration: const BoxDecoration(
                          gradient: LinearGradient(
                              colors: [Color(0xFFe37b7b), Color(0xFFF6CBCA)],
                              begin: FractionalOffset(0.0, 0.0),
                              end: FractionalOffset(0.75, 0.0),
                              stops: [0.0, 1.0],
                              tileMode: TileMode.clamp),
                          borderRadius: BorderRadius.all(Radius.circular(25))),
                      child: Center(
                        child: Text(
                          'Send',
                          style: TextStyle(
                              fontSize: 22, fontWeight: FontWeight.w600),
                        ),
                      ),
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: new BorderRadius.circular(28),
                    ),
                    elevation: 8,
                  ),
                ), //Login Button
                Padding(
                  padding: EdgeInsets.all(10),
                ),
              ],
            ))
      ],
    );
  }
}
