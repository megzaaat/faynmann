import 'package:bmnav/bmnav.dart';
import 'package:flutter/material.dart';
import 'package:immunity/ui/ConfirmLogin.dart';
import 'package:immunity/ui/SignUp.dart';
import 'package:bmnav/bmnav.dart' as bmnav;

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int _selectedIndex = 0;
  static const TextStyle optionStyle =
      TextStyle(fontSize: 40, fontWeight: FontWeight.bold);
  static const List<Widget> _widgetOptions = <Widget>[
    Text(
      'Index 0: Home',
      style: optionStyle,
    ),
    Text(
      'Index 1: Business',
      style: optionStyle,
    ),
    Text(
      'Index 2: School',
      style: optionStyle,
    ),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }


  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        Container(
          color: Colors.white,
        ),
        Image.asset(
          "images/BG.png",
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          fit: BoxFit.cover,
          color: Color(0xFFfafafa),
        ),
        Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0,
            iconTheme: IconThemeData(color: Color(0xFF4E7A9F)),
          ),
          body: ListView(
            padding: EdgeInsets.only(top: 80, left: 30, right: 30),
            children: <Widget>[
              Text(""),
              Image(
                image: AssetImage('images/heartRate.png'),
                height: 300,
              ),
              Padding(
                padding: EdgeInsets.all(15),
              ),
              RaisedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ConfirmLogin()),
                  );
                },
                textColor: Colors.white,
                padding: const EdgeInsets.all(0.07),
                child: Container(
                    height: MediaQuery.of(context).size.height * 0.08,
                    width: MediaQuery.of(context).size.width,
                    decoration: const BoxDecoration(
                        gradient: LinearGradient(
                            colors: [Color(0xFFe37b7b), Color(0xFFF6CBCA)],
                            begin: FractionalOffset(0.0, 0.0),
                            end: FractionalOffset(0.75, 0.0),
                            stops: [0.0, 1.0],
                            tileMode: TileMode.clamp),
                        borderRadius: BorderRadius.all(Radius.circular(25))),
                    padding: const EdgeInsets.all(10.0),
                    child: Row(
                      children: <Widget>[
                        Padding(padding: EdgeInsets.only(left: 10)),
                        Icon(
                          Icons.location_on,
                          size: 28,
                        ),
                        Padding(padding: EdgeInsets.only(left: 10)),
                        Center(
                          child: Text(
                            'Search by Area , Specialty',
                            style: TextStyle(
                                fontSize: 22, fontWeight: FontWeight.w600),
                          ),
                        ),
                      ],
                    )),
                shape: RoundedRectangleBorder(
                  borderRadius: new BorderRadius.circular(28),
                ),
                elevation: 8,
              ), //Login Button
              Padding(
                padding: EdgeInsets.all(15),
              ),
              RaisedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => SignUp()),
                  );
                },
                textColor: Colors.white,
                padding: const EdgeInsets.all(0.07),
                child: Container(
                    height: MediaQuery.of(context).size.height * 0.08,
                    width: MediaQuery.of(context).size.width,
                    decoration: const BoxDecoration(
                        gradient: LinearGradient(
                            colors: [Color(0xFFe37b7b), Color(0xFFF6CBCA)],
                            begin: FractionalOffset(0.0, 0.0),
                            end: FractionalOffset(0.75, 0.0),
                            stops: [0.0, 1.0],
                            tileMode: TileMode.clamp),
                        borderRadius: BorderRadius.all(Radius.circular(25))),
                    padding: const EdgeInsets.all(10.0),
                    child: Row(
                      children: <Widget>[
                        Padding(padding: EdgeInsets.only(left: 10)),
                        Icon(
                          Icons.search,
                          size: 28,
                        ),
                        Padding(padding: EdgeInsets.only(left: 10)),
                        Center(
                          child: Text(
                            'Search by Doctor name',
                            style: TextStyle(
                                fontSize: 22, fontWeight: FontWeight.w600),
                          ),
                        ),
                      ],
                    )),
                shape: RoundedRectangleBorder(
                  borderRadius: new BorderRadius.circular(28),
                ),
                elevation: 8,
              ),
              Padding(
                padding: EdgeInsets.all(15),
              ),
            ],
          ),
          bottomNavigationBar: BottomNavigationBar(
            items:  <BottomNavigationBarItem>[
              BottomNavigationBarItem(
                icon: Icon(Icons.home),
                title: Text('Home'),
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.business),
                title: Text('Business'),
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.school),
                title: Text('School'),
              ),
            ],

            onTap: (int index){
              setState((){
                _selectedIndex=index;
              });
            },
          ),
        ),
      ],
    );
  }
}
