import 'package:flutter/material.dart';
import 'package:immunity/ui/login.dart';
import 'package:immunity/ui/ConfirmLogin.dart';
import 'package:immunity/ui/SignUp.dart';
import 'package:http/http.dart' as http;



void main (){
  runApp(MaterialApp(
    theme: ThemeData(fontFamily: 'Cairo',),
    home: Login(),
    debugShowCheckedModeBanner: false,
    routes: <String, WidgetBuilder> {
      '/Login': (BuildContext context) => Login(),
    },
  )
  );
}
