import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class Data {
  final String fullName;
  final String mail;
  final String password;
  final String confirmPass;
  final String phone;
  final String date;
  final String gender;
  Data({this.fullName,this.mail,this.password,this.confirmPass,this.phone,this.date,this.gender});
  factory Data.fromJson(Map<String, dynamic> json) {
    return Data(
      fullName: json['userId'],
      gender: json['id'],
      mail: json['title'],
      password: json['body'],

    );
  }
  Map toMap() {
    var map = new Map<String, dynamic>();
    map["userId"] = fullName;
    map["title"] = mail;

    return map;
  }
  Future<Data> createPost(String url, {Map body}) async {
    return http.post(url, body: body).then((http.Response response) {
      final int statusCode = response.statusCode;

      if (statusCode < 200 || statusCode > 400 || json == null) {
        throw new Exception("Error while fetching data");
      }
      return Data.fromJson(json.decode(response.body));
    });
  }

}